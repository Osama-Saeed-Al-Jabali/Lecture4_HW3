﻿namespace WindowsFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUp = new System.Windows.Forms.Button();
            this.btnSumUp = new System.Windows.Forms.Button();
            this.btnMinDown = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnSumRight = new System.Windows.Forms.Button();
            this.btnMinLeft = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnPlayer = new System.Windows.Forms.Button();
            this.rdoUp = new System.Windows.Forms.RadioButton();
            this.rdoDown = new System.Windows.Forms.RadioButton();
            this.chkFive = new System.Windows.Forms.CheckBox();
            this.chkTen = new System.Windows.Forms.CheckBox();
            this.chkTwenty = new System.Windows.Forms.CheckBox();
            this.chkFifteen = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnUp
            // 
            this.btnUp.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUp.Location = new System.Drawing.Point(951, 54);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(50, 46);
            this.btnUp.TabIndex = 0;
            this.btnUp.Text = "^";
            this.btnUp.UseVisualStyleBackColor = false;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnSumUp
            // 
            this.btnSumUp.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSumUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSumUp.Location = new System.Drawing.Point(951, 125);
            this.btnSumUp.Name = "btnSumUp";
            this.btnSumUp.Size = new System.Drawing.Size(50, 46);
            this.btnSumUp.TabIndex = 1;
            this.btnSumUp.Text = "+";
            this.btnSumUp.UseVisualStyleBackColor = false;
            this.btnSumUp.Click += new System.EventHandler(this.btnSumUp_Click);
            // 
            // btnMinDown
            // 
            this.btnMinDown.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMinDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinDown.Location = new System.Drawing.Point(951, 251);
            this.btnMinDown.Name = "btnMinDown";
            this.btnMinDown.Size = new System.Drawing.Size(50, 46);
            this.btnMinDown.TabIndex = 2;
            this.btnMinDown.Text = "-";
            this.btnMinDown.UseVisualStyleBackColor = false;
            this.btnMinDown.Click += new System.EventHandler(this.btnMinDown_Click);
            // 
            // btnDown
            // 
            this.btnDown.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDown.Location = new System.Drawing.Point(951, 315);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(50, 46);
            this.btnDown.TabIndex = 3;
            this.btnDown.Text = "v";
            this.btnDown.UseVisualStyleBackColor = false;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRight.Location = new System.Drawing.Point(1100, 187);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(50, 46);
            this.btnRight.TabIndex = 4;
            this.btnRight.Text = ">";
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnSumRight
            // 
            this.btnSumRight.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSumRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSumRight.Location = new System.Drawing.Point(1023, 187);
            this.btnSumRight.Name = "btnSumRight";
            this.btnSumRight.Size = new System.Drawing.Size(50, 46);
            this.btnSumRight.TabIndex = 5;
            this.btnSumRight.Text = "+";
            this.btnSumRight.UseVisualStyleBackColor = false;
            this.btnSumRight.Click += new System.EventHandler(this.btnSumRight_Click);
            // 
            // btnMinLeft
            // 
            this.btnMinLeft.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMinLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinLeft.Location = new System.Drawing.Point(878, 187);
            this.btnMinLeft.Name = "btnMinLeft";
            this.btnMinLeft.Size = new System.Drawing.Size(50, 46);
            this.btnMinLeft.TabIndex = 6;
            this.btnMinLeft.Text = "-";
            this.btnMinLeft.UseVisualStyleBackColor = false;
            this.btnMinLeft.Click += new System.EventHandler(this.btnMinLeft_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeft.Location = new System.Drawing.Point(793, 187);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(50, 46);
            this.btnLeft.TabIndex = 7;
            this.btnLeft.Text = "<";
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnPlay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.ForeColor = System.Drawing.Color.Red;
            this.btnPlay.Location = new System.Drawing.Point(15, 444);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(112, 43);
            this.btnPlay.TabIndex = 8;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = false;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnPlayer
            // 
            this.btnPlayer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnPlayer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlayer.ForeColor = System.Drawing.Color.Red;
            this.btnPlayer.Location = new System.Drawing.Point(369, 192);
            this.btnPlayer.Name = "btnPlayer";
            this.btnPlayer.Size = new System.Drawing.Size(130, 69);
            this.btnPlayer.TabIndex = 9;
            this.btnPlayer.Text = "Player";
            this.btnPlayer.UseVisualStyleBackColor = false;
            // 
            // rdoUp
            // 
            this.rdoUp.AutoSize = true;
            this.rdoUp.Location = new System.Drawing.Point(15, 31);
            this.rdoUp.Name = "rdoUp";
            this.rdoUp.Size = new System.Drawing.Size(47, 20);
            this.rdoUp.TabIndex = 10;
            this.rdoUp.TabStop = true;
            this.rdoUp.Text = "UP";
            this.rdoUp.UseVisualStyleBackColor = true;
            // 
            // rdoDown
            // 
            this.rdoDown.AutoSize = true;
            this.rdoDown.Location = new System.Drawing.Point(15, 72);
            this.rdoDown.Name = "rdoDown";
            this.rdoDown.Size = new System.Drawing.Size(71, 20);
            this.rdoDown.TabIndex = 11;
            this.rdoDown.TabStop = true;
            this.rdoDown.Text = "DOWN";
            this.rdoDown.UseVisualStyleBackColor = true;
            // 
            // chkFive
            // 
            this.chkFive.AutoSize = true;
            this.chkFive.Location = new System.Drawing.Point(15, 135);
            this.chkFive.Name = "chkFive";
            this.chkFive.Size = new System.Drawing.Size(36, 20);
            this.chkFive.TabIndex = 12;
            this.chkFive.Text = "5";
            this.chkFive.UseVisualStyleBackColor = true;
            // 
            // chkTen
            // 
            this.chkTen.AutoSize = true;
            this.chkTen.Location = new System.Drawing.Point(15, 177);
            this.chkTen.Name = "chkTen";
            this.chkTen.Size = new System.Drawing.Size(43, 20);
            this.chkTen.TabIndex = 13;
            this.chkTen.Text = "10";
            this.chkTen.UseVisualStyleBackColor = true;
            // 
            // chkTwenty
            // 
            this.chkTwenty.AutoSize = true;
            this.chkTwenty.Location = new System.Drawing.Point(15, 261);
            this.chkTwenty.Name = "chkTwenty";
            this.chkTwenty.Size = new System.Drawing.Size(43, 20);
            this.chkTwenty.TabIndex = 14;
            this.chkTwenty.Text = "20";
            this.chkTwenty.UseVisualStyleBackColor = true;
            // 
            // chkFifteen
            // 
            this.chkFifteen.AutoSize = true;
            this.chkFifteen.Location = new System.Drawing.Point(15, 219);
            this.chkFifteen.Name = "chkFifteen";
            this.chkFifteen.Size = new System.Drawing.Size(43, 20);
            this.chkFifteen.TabIndex = 15;
            this.chkFifteen.Text = "15";
            this.chkFifteen.UseVisualStyleBackColor = true;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1186, 501);
            this.Controls.Add(this.chkFifteen);
            this.Controls.Add(this.chkTwenty);
            this.Controls.Add(this.chkTen);
            this.Controls.Add(this.chkFive);
            this.Controls.Add(this.rdoDown);
            this.Controls.Add(this.rdoUp);
            this.Controls.Add(this.btnPlayer);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnMinLeft);
            this.Controls.Add(this.btnSumRight);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnMinDown);
            this.Controls.Add(this.btnSumUp);
            this.Controls.Add(this.btnUp);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnSumUp;
        private System.Windows.Forms.Button btnMinDown;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnSumRight;
        private System.Windows.Forms.Button btnMinLeft;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnPlayer;
        private System.Windows.Forms.RadioButton rdoUp;
        private System.Windows.Forms.RadioButton rdoDown;
        private System.Windows.Forms.CheckBox chkFive;
        private System.Windows.Forms.CheckBox chkTen;
        private System.Windows.Forms.CheckBox chkTwenty;
        private System.Windows.Forms.CheckBox chkFifteen;
    }
}